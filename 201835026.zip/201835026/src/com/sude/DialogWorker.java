package com.sude;

import com.sude.entities.abstracts.classes.User;
import com.sude.entities.concretes.Observer;
import com.sude.entities.concretes.Student;

import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class DialogWorker<T extends User> {
    private T User;

    public DialogWorker(T user) {
        User = user;
    }

    public T getUser() {
        return User;
    }

    public void setUser(T user) { User = user;
    }

    public boolean Dialog() {

        if (User instanceof Student) {
            System.out.printf("Hello Student: %s\n", User.getFirstName() + " " + User.getLastName());

            while (true) {
                System.out.println("Here is your actions:");
                System.out.println("1) Get lectures:");
                System.out.println("2) Get grades:");
                System.out.println("3) Get attendance:");
                System.out.println("4) Get observer number:");
                System.out.println("5) Log Out:");
                Scanner input1 = new Scanner(System.in);
                System.out.println("Enter number above: ");
                String input = input1.next();
                if (input.equals("4")) {
                    var observer = ((Student) User).getObserver();
                    System.out.println("Observer Id: " + observer.getObserverNumber() + "\nObserver Name and Surname: "
                            + observer.getFirstName() + " " + observer.getLastName());
                    continue;
                }
                else if (input.equals("5")) {
                    System.out.println("Successfully logged out");
                    break;
                }
                else if(input.equals("3")){
                    var attendanceList = ((Student) User).getAttendance();
                    attendanceList.forEach((attendance) -> System.out.println(
                            attendance.getLecture().getName()
                                    + " : "
                                    + attendance.getWeek()
                                    + " - "
                                    + attendance.getLectureCount()));
                    break;
                }
                else if(input.equals("2")){
                    var grades = ((Student) User).getGrades();
                    grades.forEach((lecture,grade) -> System.out.println(lecture.getName() + " : " + grade ));
                    break;
                }

                else if(input.equals("1")){
                    var lectures = ((Student) User).getLectures();
                    lectures.forEach(lecture -> {
                        System.out.println(lecture.getName() + " - hours: ");
                        lecture.getLectureTimes().forEach(lectureTime-> System.out.println(lectureTime.getDay() + " : " +lectureTime.getHour()));
                    });

                    break;
                }
                else{
                    System.out.println("Invalid input");
                    continue;
                }
            }
        } else if (User instanceof Observer) {

                System.out.printf("Hello Observer: %s\n", User.getFirstName() + " " + User.getLastName());
            while (true) {
                System.out.println("Here is your actions:");
                System.out.println("1) Get related students:");
                System.out.println("2) Get observer number:");
                System.out.println("3) Log Out:");
                Scanner input1 = new Scanner(System.in);
                System.out.println("Enter number above: ");
                String input = input1.next();
                if (input.equals("2")) {
                    System.out.println("Observer Id: " + ((Observer) User).getObserverNumber());
                    continue;
                } else if (input.equals("3")) {
                    System.out.println("Successfully logged out");
                    break;
                } else if (input.equals("1")) {
                    var Students = ((Observer) User).getRelatedStudents();
                    AtomicInteger index = new AtomicInteger();
                    //LAMBDA EXPRESSION
                    Students.forEach(student -> System.out.println(
                            (index.getAndIncrement() + 1)
                                    + ") "
                                    + "Student Name: "
                                    + student.getFirstName() +
                                    " " + student.getLastName() +
                                    "\nStudent Number: " +
                                    student.getStudentNumber()

                    ));

                   while (true){
                       Scanner input2 = new Scanner(System.in);
                       System.out.println("Select a student:");
                       input = input2.next();
                       var result = parseIntOrNull(input);
                       System.out.println(result);
                       if(result == null){
                           System.out.println(result);
                           continue;
                       }else if(result > Students.size()){
                           System.out.println(result);
                           continue;
                       }else {
                           var selectedStudent = Students.get(result-1);
                           System.out.println("Here is your actions:");
                           System.out.println("1) Get student grades list:");
                           System.out.println("2) Get student attendance list:");
                           Scanner input3 = new Scanner(System.in);
                           System.out.println("Select an action:");
                           input = input3.next();
                           if(input.equals("1")){
                               var grades = selectedStudent.getGrades();
                               grades.forEach((lecture,grade) -> System.out.println(lecture.getName() + " : " + grade ));
                               break;
                           }
                           else if(input.equals("2")){
                               var attendanceList = selectedStudent.getAttendance();
                               attendanceList.forEach((attendance) -> System.out.println(
                                       attendance.getLecture().getName()
                                               + " : "
                                               + attendance.getWeek()
                                               + " - "
                                               + attendance.getLectureCount()));
                               break;
                           }
                           else{
                               System.out.println("Invalid input");
                               continue;
                           }
                       }
                   }
                   break;

                }
            }
        }

        return false;
    }

    public Integer parseIntOrNull(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

}
