package com.sude.entities.concretes;

public class Attendance {
    private Lecture lecture;
    private int week;
    private int lectureCount;

    public Lecture getLecture() {
        return lecture;
    }

    public void setLecture(Lecture lecture) {
        this.lecture = lecture;
    }

    public Attendance(Lecture lecture, int week, int lectureCount) {
        this.lecture = lecture;
        this.week = week;
        this.lectureCount = lectureCount;
    }

    public int getWeek() {
        return week;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    public int getLectureCount() {
        return lectureCount;
    }

    public void setLectureCount(int lectureCount) {
        this.lectureCount = lectureCount;
    }
}
