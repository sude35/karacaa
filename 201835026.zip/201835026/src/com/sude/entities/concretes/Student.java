package com.sude.entities.concretes;

import com.sude.entities.abstracts.classes.User;

import java.util.List;
import java.util.Map;

public class Student extends User {
    private String StudentNumber;
    private List<Lecture> Lectures;
    private Map<Lecture, Double> Grades;
    private List<Attendance> Attendance;
    private Observer observer;
    public Student(){
        super();

    };
    public Student(
            int id,
            String firstName,
            String lastName,
            int gender,
            String studentNumber,
            List<Lecture> lectures,
            Map<Lecture, Double> grades,
            List<Attendance> attendance, Observer observer) {
        super(id, firstName, lastName, gender);
        StudentNumber = studentNumber;
        Lectures = lectures;
        Grades = grades;
        Attendance = attendance;
        this.observer = observer;
    }

    public String getStudentNumber() {
        return StudentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        StudentNumber = studentNumber;
    }

    public List<Lecture> getLectures() {
        return Lectures;
    }

    public void setLectures(List<Lecture> lectures) {
        Lectures = lectures;
    }

    public Map<Lecture, Double> getGrades() {
        return Grades;
    }

    public void setGrades(Map<Lecture, Double> grades) {
        Grades = grades;
    }

    public List<com.sude.entities.concretes.Attendance> getAttendance() {
        return Attendance;
    }

    public void setAttendance(List<com.sude.entities.concretes.Attendance> attendance) {
        Attendance = attendance;
    }

    public Observer getObserver() {
        return observer;
    }

    public void setObserver(Observer observer) {
        this.observer = observer;
    }
}
