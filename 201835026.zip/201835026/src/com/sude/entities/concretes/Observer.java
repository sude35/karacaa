package com.sude.entities.concretes;

import com.sude.entities.abstracts.classes.User;

import java.util.List;

public class Observer extends User {
    private String ObserverNumber;
    private List<Student> RelatedStudents;
    public Observer(){
        super();
    }
    public Observer(int id, String firstName, String lastName, int gender, String observerNumber, List<Student> relatedStudents) {
        super(id, firstName, lastName, gender);
        ObserverNumber = observerNumber;
        RelatedStudents = relatedStudents;
    }

    public String getObserverNumber() {
        return ObserverNumber;
    }

    public void setObserverNumber(String observerNumber) {
        ObserverNumber = observerNumber;
    }

    public List<Student> getRelatedStudents() {
        return RelatedStudents;
    }

    public void setRelatedStudents(List<Student> relatedStudents) {
        RelatedStudents = relatedStudents;
    }
}
