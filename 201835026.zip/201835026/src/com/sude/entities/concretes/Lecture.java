package com.sude.entities.concretes;

import java.util.List;

public class Lecture {
    private String name;
    private List<LectureTime> lectureTimes;

    public Lecture(String name, List<LectureTime> lectureTimes) {
        this.name = name;
        this.lectureTimes = lectureTimes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<LectureTime> getLectureTimes() {
        return lectureTimes;
    }

    public void setLectureTimes(List<LectureTime> lectureTimes) {
        this.lectureTimes = lectureTimes;
    }
}
