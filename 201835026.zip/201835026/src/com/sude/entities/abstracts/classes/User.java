package com.sude.entities.abstracts.classes;

import com.sude.entities.abstracts.interfaces.IEntity;

public class User implements IEntity {
    protected int Id;
    protected String FirstName;
    protected String LastName;
    protected int Gender;

    public User(int id, String firstName, String lastName, int gender) {
        Id = id;
        FirstName = firstName;
        LastName = lastName;
        Gender = gender;
    }

    public User() {

    }

    public void Print(){
        System.out.printf("Name: %s\nSurname: %s\nWelcome",this.FirstName,this.LastName);
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public int isGender() {
        return Gender;
    }

    public void setGender(int gender) {
        Gender = gender;
    }
}
