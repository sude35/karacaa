package com.sude.entities.abstracts.interfaces;

public interface IEntity {
    void Print();
}
