package com.sude;

import com.sude.entities.abstracts.classes.User;
import com.sude.entities.concretes.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Lecture math = new Lecture(
                "Math 101",
                Arrays.asList(
                        new LectureTime(3, 12),
                        new LectureTime(4, 15)
                )
        );
        Lecture physics = new Lecture(
                "Physics 101",
                Arrays.asList(
                        new LectureTime(1, 11),
                        new LectureTime(2, 14)
                )
        );
        Student student1 = new Student();
        student1.setFirstName("Tuğçe");
        student1.setLastName("Özdemir");
        student1.setLectures(Arrays.asList(physics,math));
        student1.setStudentNumber("201825016");
        student1.setGender(0);
        student1.setGrades(Map.ofEntries(
                Map.entry(math, 75.89),
                Map.entry(physics, 77.00)
        ));
        student1.setAttendance(Arrays.asList(
                new Attendance(physics, 1, 3),
                new Attendance(physics, 2, 2),
                new Attendance(physics, 3, 3),
                new Attendance(math, 3, 3),
                new Attendance(math, 2, 3),
                new Attendance(math, 1, 3)
        ));
        Student student2 = new Student();
        student2.setFirstName("Mert");
        student2.setLastName("Acar");
        student2.setStudentNumber("201928952");

        student2.setLectures(Arrays.asList(physics,math));
        student2.setGender(1);
        student2.setGrades(Map.ofEntries(
                Map.entry(math, 75.89),
                Map.entry(physics, 77.00)
        ));
        student2.setAttendance(Arrays.asList(
                new Attendance(physics, 1, 1),
                new Attendance(physics, 2, 2),
                new Attendance(physics, 3, 2),
                new Attendance(math, 3, 3),
                new Attendance(math, 2, 3),
                new Attendance(math, 1, 3)
        ));
        Observer observer1 = new Observer();
        observer1.setObserverNumber("200878789");
        observer1.setFirstName("Ayşe");
        observer1.setLastName("Kılıç");
        observer1.setGender(0);
        observer1.setRelatedStudents(Arrays.asList(student1, student2));
        student1.setObserver(observer1);
        student2.setObserver(observer1);
        Scanner input1 = new Scanner(System.in);
        System.out.println("Enter User Number : ");
        String userNumber = input1.next();
        Map<String, User> allUsers = new HashMap<>() {{
            put("201825016", student1);
            put("201928952", student2);
            put("200878789", observer1);
        }};

        var result = allUsers.get(userNumber);
        if (!(result == null)) {

            System.out.println("Access Granted! Welcome!");
            DialogWorker dialogWorker = new DialogWorker<>(result);
            dialogWorker.Dialog();
        } else {
            System.out.println("Invalid Username & Password!");
        }
    }
}
